# -*- coding: utf-8 -*-
"""
Created on Mon Oct 12 07:14:43 2020

@author: Shuxia Guo
"""

import os
import pickle
import numpy as np
from radiomics import featureextractor
import SimpleITK as sitk
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings("ignore")

def gauss_kernel_3d(sigma, size):
    
    # make 3d gauss kernel adaptive to size
    x,y,z = [i for i in size]
    voxel_size = np.asarray([3*sigma/i for i in size])
    
    #make 3d grid of euclidean distances from center
    distances = voxel_size*np.ogrid[-x:x+1,-y:y+1,-z:z+1]
    distances = np.sum( distances*distances )
    
    return np.exp( distances/ -2*sigma**2 )/ np.sqrt( np.pi*2*sigma**2)**3
 

def cal_features(im_data, im_dim):    
    
    im_data = np.asarray(im_data)
    im3d = im_data.reshape(im_dim[2], im_dim[0], im_dim[1])
       
    im3d = np.uint8((im3d-np.min(im3d))/(np.max(im3d)-np.min(im3d))*255)
    
    print('prepare mask')
    
    maskHP = gauss_kernel_3d(0.01, [im_dim[2]//2, im_dim[0]//2, im_dim[1]//2])
    maskHP = maskHP[:im_dim[2], :im_dim[0], :im_dim[1]]
    maskHP = (maskHP-np.min(maskHP))/(np.max(maskHP)-np.min(maskHP))
    
    ma = np.zeros([im_dim[2], im_dim[0], im_dim[1]], dtype='uint8')
    ma[maskHP>0.707] = 1
    im_label = sitk.GetImageFromArray(ma)
    im3d = sitk.GetImageFromArray(im3d)
    
    print('prepare feature extraction')
    
    extractor = featureextractor.RadiomicsFeatureExtractor()
    extractor.disableAllFeatures()
    extractor.enableFeatureClassByName('firstorder')
    
    print('start feature extraction')
         
    fea = extractor.computeFeatures(im3d, im_label, 'Original')
    
    
    feas = []
    for item, value in fea.items():
        feas = np.append(feas, value)

    print('finish feature extraction')
    
    feas = feas.reshape(1, -1)
    
    cdir = os.getcwd()
    scaler = pickle.load(open(os.path.join(cdir, 'plugins\\imPreProcess\\scaler.sav'), 'rb'))
    lr = pickle.load(open(os.path.join(cdir, 'plugins\\imPreProcess\\model.sav'), 'rb'))
    print('finish load model')
    
    x_test = scaler.transform(feas)
 
    pred = lr.predict(x_test)[0]
    print('finish classification: '+ pred)
    
    val = -1
    if pred=='Good': val=100
    elif pred=='Median': val=0
    elif pred=='Bad': val=-100
    return val